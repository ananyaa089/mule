"""Diagnose why IBM-pattern mules are invisible to the model.

    python src/diagnose_ibm.py

Compares IBM-pattern mules against ordinary accounts (injected mules and decoys are EXCLUDED, so this is
purely the "slow, structural" group) on the TRAIN window, and answers:
  1. Which existing features separate them at all?          (single-feature ROC-AUC)
  2. Can a model trained only on them find them?            (ibm-only model, held-out part of train + val)
  3. What do they look like per pattern type?               (shape of in/out activity)
  4. Is 'same amount forwarded within days' a usable signal? (candidate new feature, tested directly)
Only reads existing tables. Writes nothing.
"""
import os

import numpy as np
import pandas as pd
import psycopg
import xgboost as xgb
from sklearn.metrics import average_precision_score, roc_auc_score

DSN = os.environ.get("MULEGUARD_DSN", "postgresql://muleguard:muleguard@localhost:5433/muleguard")
pd.set_option("display.width", 200)


def q(conn, sql, params=None):
    cur = conn.execute(sql, params)
    return pd.DataFrame.from_records(cur.fetchall(), columns=[d.name for d in cur.description], coerce_float=True)


def load(conn, split):
    gtab = f"graph_features_{split}"
    has_g = conn.execute("SELECT to_regclass(%s)", (gtab,)).fetchone()[0] is not None
    join = f"LEFT JOIN {gtab} g USING (acct_id)" if has_g else ""
    gsel = ", g.*" if has_g else ""
    df = q(conn, f"""SELECT f.*{gsel}, l.y, l.label, l.source, l.typology
                     FROM features_{split} f JOIN labels_{split} l USING (acct_id) {join}""")
    df = df.loc[:, ~df.columns.duplicated()]
    # keep: IBM mules (positives) and plain accounts (negatives). Drop injected mules + decoys.
    ibm = (df["y"] == 1) & (df["source"] == "ibm")
    plain = (df["y"] == 0) & (df["label"] != "decoy")
    out = df[ibm | plain].copy()
    out["is_ibm"] = ibm[ibm | plain].astype(int)
    return out


def numeric(df):
    skip = {"acct_id", "y", "label", "source", "typology", "is_ibm", "kyc_level", "account_type"}
    return [c for c in df.columns if c not in skip and pd.api.types.is_numeric_dtype(df[c])]


def main():
    with psycopg.connect(DSN) as conn:
        tr, va = load(conn, "train"), load(conn, "val")
        print(f"train: {int(tr['is_ibm'].sum()):,} IBM-pattern mules vs {int((1 - tr['is_ibm']).sum()):,} plain accounts")
        print(f"val  : {int(va['is_ibm'].sum()):,} IBM-pattern mules vs {int((1 - va['is_ibm']).sum()):,} plain accounts")

        cols = numeric(tr)
        print("\n=== 1. single-feature ROC-AUC, IBM mules vs plain accounts (train) ===")
        print("    0.5 = no signal.  Distance from 0.5 matters; below 0.5 just means 'lower for mules'.")
        rows = []
        for c in cols:
            x = tr[c].fillna(-1)
            if x.nunique() > 1:
                a = roc_auc_score(tr["is_ibm"], x)
                rows.append((c, round(a, 3), round(abs(a - 0.5), 3)))
        r = pd.DataFrame(rows, columns=["feature", "auc", "|auc-0.5|"]).sort_values("|auc-0.5|", ascending=False)
        print(r.head(15).to_string(index=False))

        print("\n=== 2. model trained ONLY on IBM mules vs plain accounts ===")
        Xtr, Xva = tr[cols].astype(float), va[cols].astype(float)
        spw = float(np.sqrt((tr["is_ibm"] == 0).sum() / max(tr["is_ibm"].sum(), 1)))
        m = xgb.XGBClassifier(n_estimators=400, learning_rate=0.05, max_depth=5, subsample=0.8, colsample_bytree=0.8,
                              scale_pos_weight=spw, tree_method="hist", eval_metric="aucpr",
                              early_stopping_rounds=40, random_state=42, n_jobs=-1)
        m.fit(Xtr, tr["is_ibm"], eval_set=[(Xva, va["is_ibm"])], verbose=False)
        s = m.predict_proba(Xva)[:, 1]
        yv = va["is_ibm"].to_numpy()
        base = yv.mean()
        print(f"val PR-AUC {average_precision_score(yv, s):.4f}   (random guessing would be {base:.4f})")
        for k in (100, 500, 1000):
            top = np.argsort(-s)[:k]
            print(f"   top {k:>4}: {int(yv[top].sum()):>4} IBM mules  (precision {yv[top].mean():.3f})")
        imp = pd.Series(m.feature_importances_, index=cols).sort_values(ascending=False).head(8)
        print("   what it uses:", ", ".join(f"{k} {v:.2f}" for k, v in imp.items()))

        print("\n=== 3. shape per pattern type (train window, medians) ===")
        ib = tr[tr["is_ibm"] == 1].copy()
        ib["only_receives"] = (ib["n_out"] == 0)
        ib["only_sends"] = (ib["n_in"] == 0)
        t = ib.groupby("typology").agg(accounts=("acct_id", "size"), only_receives=("only_receives", "mean"),
                                       only_sends=("only_sends", "mean"), med_n_in=("n_in", "median"),
                                       med_n_out=("n_out", "median"), med_total_in=("total_in", "median"),
                                       med_span_h=("active_span_s", lambda v: float(np.nanmedian(v)) / 3600))
        print(t.round(2).sort_values("accounts", ascending=False).to_string())
        pl = tr[tr["is_ibm"] == 0]
        print(f"plain accounts: only_receives {(pl['n_out'] == 0).mean():.2f}, only_sends {(pl['n_in'] == 0).mean():.2f}, "
              f"med n_in {pl['n_in'].median():.0f}, med n_out {pl['n_out'].median():.0f}, med total_in {pl['total_in'].median():,.0f}")

        print("\n=== 4. candidate feature: an outbound of (nearly) the SAME amount within 7 days of an inbound ===")
        start, end = conn.execute("SELECT start_ts, end_ts FROM splits WHERE name = 'train'").fetchone()
        ids_ibm = tr.loc[tr["is_ibm"] == 1, "acct_id"].tolist()
        both = pl[(pl["n_in"] > 0) & (pl["n_out"] > 0)]
        ids_pl = both.sample(min(5000, len(both)), random_state=1)["acct_id"].tolist()
        res = {}
        for name, ids in (("IBM mules", ids_ibm), ("plain (sampled)", ids_pl)):
            d = q(conn, """
                WITH s AS (SELECT unnest(%s::text[]) AS acct_id)
                SELECT s.acct_id,
                  EXISTS (SELECT 1 FROM transactions i WHERE i.dst = s.acct_id AND i.ts >= %s AND i.ts < %s) AS has_in,
                  EXISTS (SELECT 1 FROM transactions i JOIN transactions o ON o.src = i.dst AND o.ts > i.ts
                          AND o.ts <= i.ts + interval '7 days' AND o.ts < %s
                          AND o.amount BETWEEN 0.97 * i.amount AND 1.001 * i.amount
                          WHERE i.dst = s.acct_id AND i.ts >= %s AND i.ts < %s AND i.amount >= 100) AS same_amt_7d,
                  EXISTS (SELECT 1 FROM transactions i JOIN transactions o ON o.src = i.dst AND o.ts > i.ts
                          AND o.ts <= i.ts + interval '7 days' AND o.ts < %s
                          WHERE i.dst = s.acct_id AND i.ts >= %s AND i.ts < %s AND i.amount >= 100) AS any_out_7d
                FROM s""", (ids, start, end, end, start, end, end, start, end))
            d = d[d["has_in"]]
            res[name] = (len(d), d["same_amt_7d"].mean(), d["any_out_7d"].mean())
        print(f"{'group':<18}{'accounts with inbound':>24}{'same-amount out <=7d':>24}{'any out <=7d':>16}")
        for k, (n, a, b) in res.items():
            print(f"{k:<18}{n:>24,}{a:>24.3f}{b:>16.3f}")

        print("\nHow to read this:")
        print(" - Section 2 near 'random guessing' => the current tables simply do not contain the signal.")
        print(" - Section 1/3 show which existing columns are worth keeping or re-engineering.")
        print(" - Section 4 a big gap (e.g. 0.30 vs 0.02) => add 'same-amount forwarding' as a feature.")


if __name__ == "__main__":
    main()
